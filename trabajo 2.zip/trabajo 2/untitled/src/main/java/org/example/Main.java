package org.example;

import org.example.entidades.*;
import java.time.LocalTime;
import java.time.LocalDate;
import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
    public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        UnidadMedida OchoPorciones = UnidadMedida.builder()
                .id(1L)
                .denominacion("8 Porciones")
                .build();
        UnidadMedida CuatroPorciones = UnidadMedida.builder()
                .id(2L)
                .denominacion("4 Porciones")
                .build();
        UnidadMedida UnLitro = UnidadMedida.builder()
                .id(3L)
                .denominacion("1 Litro")
                .build();

        Imagen imagen1 = Imagen.builder()
                .id(1L)
                .denominacion("Pizza Grande Hawaiana")
                .build();
        Imagen imagen2 = Imagen.builder()
                .id(2L)
                .denominacion("Pizza Grande Napolitana")
                .build();
        Imagen imagen3 = Imagen.builder()
                .id(3L)
                .denominacion("Pizza Grande Muzza")
                .build();
        Imagen imagen4 = Imagen.builder()
                .id(4L)
                .denominacion("Pizza Chica Hawaiana")
                .build();
        Imagen imagen5 = Imagen.builder()
                .id(5L)
                .denominacion("Pizza Chica Napolitana")
                .build();
        Imagen imagen6 = Imagen.builder()
                .id(6L)
                .denominacion("Pizza Chica Muzza")
                .build();
        Imagen imagen7 = Imagen.builder()
                .id(7L)
                .denominacion("Pizza Cerveza Andes")
                .build();
        Imagen imagen8 = Imagen.builder()
                .id(8L)
                .denominacion("Pizza Cerveza Quilmes")
                .build();
        TipoPromocion imahappy1 = TipoPromocion.happyHour;
        TipoPromocion imahappy2 = TipoPromocion.happyHour;
        TipoPromocion verano1  = TipoPromocion.Verano;
        TipoPromocion verano2 = TipoPromocion.Verano;
        TipoPromocion invierno1  = TipoPromocion.Invierno;
        TipoPromocion invierno2  = TipoPromocion.Invierno;

        Articulo cerveza1 = Articulo.builder()
                .id(1L)
                .denominacion("Cerveza Andes")
                .precioVenta(100d)
                .precioCompra(80d)
                .stockActual(10)
                .stockMaximo(25)
                .build();


        Articulo cerveza2 = Articulo.builder()
                .id(2L )
                .denominacion("Cerveza Quilmes")
                .precioVenta(90d)
                .precioCompra(50d)
                .stockActual(20)
                .stockMaximo(30)
                .build();

        Articulo pizza1 = Articulo.builder()
                .id(3L )
                .denominacion("Pizza grande Hawaiana")
                .precioVenta(50d)
                .precioCompra(45d)
                .stockActual(10)
                .stockMaximo(15)
                .build();

        Articulo pizza2 = Articulo.builder()
                .id(4L )
                .denominacion("Pizza chica Hawaiana")
                .precioVenta(70d)
                .precioCompra(55d)
                .stockActual(15)
                .stockMaximo(15)
                .build();

        Articulo pizza3 = Articulo.builder()
                .id(4L )
                .denominacion("Pizza grande Napolitana")
                .precioVenta(70d)
                .precioCompra(65d)
                .stockActual(20)
                .stockMaximo(25)
                .build();

        Articulo pizza4 = Articulo.builder()
                .id(4L )
                .denominacion("Pizza chica Napolitana")
                .precioVenta(100d)
                .precioCompra(65d)
                .stockActual(25)
                .stockMaximo(25)
                .build();

        Articulo pizza5 = Articulo.builder()
                .id(5L )
                .denominacion("Pizza grande Muzza")
                .precioVenta(50d)
                .precioCompra(45d)
                .stockActual(10)
                .stockMaximo(12)
                .build();

        Articulo pizza6 = Articulo.builder()
                .id(6L )
                .denominacion("Pizza chica Muzza ")
                .precioVenta(100d)
                .precioCompra(90d)
                .stockActual(5)
                .stockMaximo(5)
                .build();

        Promocion promocion1 = Promocion.builder()
                .id(1L)
                .denominacion("Promo 1")
                .FechaDesde(LocalDate.of(2023, 9, 2))
                .FechaHasta(LocalDate.now())
                .HoraDesde(LocalTime.of());

    }
}