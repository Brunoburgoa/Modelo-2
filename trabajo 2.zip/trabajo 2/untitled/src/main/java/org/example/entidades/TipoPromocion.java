package org.example.entidades;
import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public enum TipoPromocion {
    happyHour,Verano,Invierno
}
